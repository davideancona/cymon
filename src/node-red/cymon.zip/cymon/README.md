
### Requirements 
* NodeJS 
* NodeRED (https://nodered.org/docs/getting-started/local) 

### Content
* README.md 
* flow.json - the "source code" 
* network-config.json - file describing the simulated network

### Instructions 
1. in the directory cymon, create a directory 'mydir' (choose your favourite name) 
2. in the directory cymon, run  'node-red -u mydir flow.json' 


