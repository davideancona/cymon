
### Description 
This is a simple tool to generate data simulating a network of sensors described by a configuration file. 
Data are published via the MQTT protocol: 
 - broker: test.mosquitto.org
 - topic: druidlab.dibris.unige.it/cymon

### Requirements 
* NodeJS 
* NodeRED (https://nodered.org/docs/getting-started/local) 

### Content
* README.md 
* flow.json - the "source code" 
* network-config.json - file describing the simulated network

### Instructions 
1. in the directory cymon, create a directory 'mydir' (choose your favourite name) 
2. in the directory cymon, run  'node-red -u mydir flow.json' 

### Configuration file 
network-config.json is a JSON file describing a network of sensors. 
It contains a *list* of objects, each one representing a sensor,  with the following properties: 
* id: the sensor identifier (string) 
* type: the sensor type (string)  
* min: the minimum value of the quantity measured by the sensor (float) 
* max: the maximum value of the quantity measured by the sensor (float) 
* per: the period (in milliseconds) of the quantity measured by the sensor (positive integer) 
* sample: the sampling period (in milliseconds) of the sensor, if not present it is 'infinity', that is, no value is generated (positive integer) 


